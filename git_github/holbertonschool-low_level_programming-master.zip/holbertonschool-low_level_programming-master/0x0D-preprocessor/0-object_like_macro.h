#ifndef SIZE
#define SIZE (1024)
#endif /* #indef SIZE */
