#include <stdio.h>

/**
 * main - main function
 * Return: int (0 or 1)
 */

int main(void)
{
	printf("%s\n", __FILE__);
	return (0);
}
