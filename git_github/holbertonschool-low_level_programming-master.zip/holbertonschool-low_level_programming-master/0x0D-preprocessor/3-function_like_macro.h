#ifndef ABS_H
#define ABS_H
#define ABS(x) ((x) >= 0 ? (x) : ((x) * -1))
#endif /* #ifndef ABS_H */
