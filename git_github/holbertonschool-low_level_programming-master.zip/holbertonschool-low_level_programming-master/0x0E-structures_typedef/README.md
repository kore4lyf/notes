0x0E. C - Structures, typedef

* What are structures, when, why and how to use them
* How to use typedef