0x10. C - Variadic functions

* What are variadic functions
* How to use va_start, va_arg and va_end macros
* Why and how to use the const type qualifier