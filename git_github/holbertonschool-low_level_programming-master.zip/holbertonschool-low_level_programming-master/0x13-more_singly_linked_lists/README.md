0x13. C - More singly linked lists

* How to use linked lists
* Start to look for the right source of information without too much help