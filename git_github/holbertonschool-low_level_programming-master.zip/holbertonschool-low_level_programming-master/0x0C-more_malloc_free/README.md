0x0C. C - More malloc, free

* How to use the exit function
* What are the functions calloc and realloc from the standard library and how to use them