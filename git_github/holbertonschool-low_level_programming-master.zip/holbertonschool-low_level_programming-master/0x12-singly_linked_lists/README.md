0x12. C - Singly linked lists

* When and why using linked lists vs arrays
* How to build and use linked lists