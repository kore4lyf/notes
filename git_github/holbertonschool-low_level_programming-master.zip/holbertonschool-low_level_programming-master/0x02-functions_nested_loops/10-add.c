#include "holberton.h"

/**
 * add - function that adds two integers and returns the result.
 * @n1: input integer 1
 * @n2: input integer 2
 * Return: int.
 */

int add(int n1, int n2)
{
	int res;

	res = n1 + n2;
	return (res);
}
