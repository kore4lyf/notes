0x09. C - Static libraries

* What is a static library, how does it work, how to create one, and how to use it
* Basic usage of ar, ranlib, nm