0x14. C - Bit manipulation

* Look for the right source of information without too much help
* How to manipulate bits and use bitwise operators