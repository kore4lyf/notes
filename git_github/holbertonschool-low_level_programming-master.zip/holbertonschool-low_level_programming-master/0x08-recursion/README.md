x08. C - Recursion

* What is recursion
* How to implement recursion
* In what situations you should implement recursion
* In what situations you shouldnt implement recursion