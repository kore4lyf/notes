0x17. C - Doubly linked lists

** General

* What is a doubly linked list
* How to use doubly linked lists
* Start to look for the right source of information without too much help