#include "holberton.h"

/**
 * mul - function that multiplies two integers.
 * @a: first input value to check
 * @b: Sec input value to check
 * Return: int.
 */

int mul(int a, int b)
{
	return (a * b);
}
