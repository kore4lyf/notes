# Hapi.js Exercise with Node.js

In this exercise you will practice a creation of a web service that respond with the block hash.

## Steps to follow

1. Clone the repository to your local computer.
2. Open the terminal and install the packages: `npm install`.
3. Open the file `app.js`and `BlockController.js` and start coding.
4. Run your application `node app.js`
5. Test your Endpoints with Curl or Postman.
6. Answer the quiz in the classroom.
