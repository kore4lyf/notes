# Block Explorer Exercise

To use this boilerplate code locally follow this steps:

1. Clone or download the project.
2. Open your project with your favorite IDE.
3. Run `npm install` to install the dependencies.
4. Implement your code.
5. Use `node app.js` to run the application.
