# Testing Smart Contracts with Solidity in Truffle

1. Check you have Truffle installed and it is the latest version (V5.0.2)
2. Run `truffle develop` or `sudo truffle develop`
3. Run `compile`
4. Run `migrate --reset`

Play around with the contracts and make some tests. Happy learning