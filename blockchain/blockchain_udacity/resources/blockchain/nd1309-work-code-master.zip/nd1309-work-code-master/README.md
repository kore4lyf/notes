# Github Repository for Blockchain ND

Welcome to your Github repository for the Blockchain ND, in this repository you will find the boilerplate code for all the code exercises and code sessions.

We are still working on this repository so if you find that a piece of code is missing please let us know submitting an issue using the waffle board: https://waffle.io/udacity/blockchain-nanodegree-issues.

The repository is divided in Courses and the projects or code sessions that is being use in each Course.

## How to use the project?

To use this boilerplate code locally follow this steps:

1. Clone or download the Github Repository.
2. Open your project with your favorite IDE.
3. Run `npm install` to install the dependencies.
4. Implement your code.
5. Use `node app.js` to run the application.



